 // IMPORTS
//import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
//import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
//import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
//import com.qualcomm.robotcore.hardware.HardwareMap;


 //package org.firstinspires.ftc.NonUsefullFiles;

 //import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
 //import com.qualcomm.robotcore.eventloop.opmode.OpMode;
 //import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
//import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
//import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
  //import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
  //import com.qualcomm.robotcore.eventloop.opmode.Autonomous;

//import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
//import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
 //import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
// import java.util.Random;
// import org.firstinspires.ftc.robotcore.external.navigation.Rotation;
// import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
 //import com.qualcomm.robotcore.hardware.*;
 //import android.graphics.Color;
 //import org.firstinspires.ftc.robotcore.external.Telemetry;
 //import java.lang.annotation.Target;
 //import com.qualcomm.robotcore.*;
 //import java.util.*;
 //import java.io.*;
 //import com.qualcomm.robotcore.hardware.LED;
 //import com.qualcomm.robotcore.hardware.DigitalChannelController;
 //import com.qualcomm.robotcore.hardware.DigitalChannel;

 //@Autonomous(name="FirstDrive",group="Linear Opmode") // name = filename, group = way to divy up code 
 // public class Filename 
 //public class FirstDrive extends LinearOpMode{
   //  LinearOpMode lom;
     //HardwareMap hwm;
      //DarienRobot robo = new DarienRobot(lom);
     // when "play" is pressed, runOpMode function will be ran 
     //public void runOpMode() {
       //  robo.runOpMode();
     //}
 //}
